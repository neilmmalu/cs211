#include<stdio.h>
#include<stdlib.h>

void add(int arr[], int n);

int search(int arr[], int n);
